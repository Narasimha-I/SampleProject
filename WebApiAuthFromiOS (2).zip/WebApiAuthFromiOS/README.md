# Connecting iOS(iPhone/iPad) Apps to Dynamics CRM using Web Api

The sample code of connecting Microsoft Dynamics CRM online with iOS apps using Web API authentication.This sample app take URL, username and password of Dynamics CRM Online and returns the full name of the logged-in user using Dynamics CRM Web API.

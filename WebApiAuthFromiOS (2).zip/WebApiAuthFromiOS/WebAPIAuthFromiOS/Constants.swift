//
//  Constants.swift
//  WebAPIAuthFromiOS
//
//  Created by Hamza on 15/02/2016.
//  Copyright © 2016 Scaleable Solutions. All rights reserved.
//

import Foundation

struct Constants {
    
    static let authority:String = "https://login.microsoftonline.com/organizations";
    static let Client_Id:String = "de3341a2-e781-4b3a-adb1-27308f0404f3"
    static let Redirect_URL:NSURL = NSURL(string: "msauth.com.virginmoney.uk.mobile.ios.dev://auth")!
    
    struct WebAPI_URLs {
        static let WhoAmIRequest_URL:String = "/api/data/v8.0/WhoAmI"
        static let FullNameRequest_URL:String = "/api/data/v8.0/systemusers(???)?$select=fullname"
    }
}

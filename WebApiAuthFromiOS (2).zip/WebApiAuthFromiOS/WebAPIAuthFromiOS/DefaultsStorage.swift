//
//  DefaultsStorage.swift
//  WebAPIAuthFromiOS
//
//  Created by Hamza on 15/02/2016.
//  Copyright © 2016 Scaleable Solutions. All rights reserved.
//

import Foundation

class DefaultsStorage{
    
    func saveDomain(domain:String){
        let defaults = UserDefaults.standard
        defaults.set(domain, forKey: "domain")
    }
    
    func getDomain() -> String{
        let defaults = UserDefaults.standard
        if let domain = defaults.string(forKey: "domain"){
            return domain
        }
        return ""
    }
    
    func removeDomain(){
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: "domain")
    }
}

//
//  ServicHandler.swift
//  WebAPIAuthFromiOS
//
//  Created by Hamza on 15/02/2016.
//  Copyright © 2016 Scaleable Solutions. All rights reserved.
//

import Foundation

protocol NetworkDelegate{
    
    func finishWithError(error:String,tag:String)
    
    func finishWithSuccess(response:NSData,tag:String)
}

class ServiceHandler {
    
    var delegate:NetworkDelegate? = nil
    var tag:String? = nil
    
    func getMethod(accessToken:String, serviceURL:String){
        let request = NSMutableURLRequest(url: NSURL(string: serviceURL)! as URL)
        request.httpMethod = "GET"
        request.setValue("application/json; odata=verbose", forHTTPHeaderField: "accept")
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest){
            data, response, error in
            
            if error != nil{
                self.delegate?.finishWithError(error: "", tag: self.tag!)
                return
            }
            self.delegate?.finishWithSuccess(response: data! as NSData, tag: self.tag!)
        }
        task.resume()
    }
}

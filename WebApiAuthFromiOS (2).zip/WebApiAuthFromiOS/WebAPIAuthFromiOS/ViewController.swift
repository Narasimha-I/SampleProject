//
//  ViewController.swift
//  WebAPIAuthFromiOS
//
//  Created by Hamza on 12/02/2016.
//  Copyright © 2016 Scaleable Solutions. All rights reserved.
//

import UIKit
import ADALiOS

class ViewController: UIViewController, NetworkDelegate {

    var er:ADAuthenticationError? = nil
    var authContext:ADAuthenticationContext? = nil
    
    var activityIndicator:UIActivityIndicatorView!
    
    @IBOutlet weak var DomainTextField: UITextField!
    
    var name:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DomainTextField.text = "https://orgdd8e0991.crm8.dynamics.com"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func finishWithError(error: String, tag: String) {
        
    }
    
    func finishWithSuccess(response: NSData, tag: String) {
        if tag == "WhoAmI"{
            do{
                let json = try JSONSerialization.jsonObject(with: response as Data, options: .allowFragments) as! [String:Any]
                
                if let User_id = json["UserId"] as? String{
                    var URL = "\(DomainTextField.text!)\(Constants.WebAPI_URLs.FullNameRequest_URL)"
                    let destinationURL = URL.replacingOccurrences(of: "???", with: User_id)
                    
                    let storage:DefaultsStorage = DefaultsStorage()
                    authContext?.acquireToken(withResource: storage.getDomain(), clientId: Constants.Client_Id, redirectUri: Constants.Redirect_URL as URL){(result:ADAuthenticationResult!) in
                        let handler:ServiceHandler = ServiceHandler()
                        handler.tag = "UserInfo"
                        handler.delegate = self
                        handler.getMethod(accessToken: result.accessToken, serviceURL: destinationURL)
                    }
                    
                }
            }catch{
                
            }
        }else if tag == "UserInfo"{
            do{
                let json = try JSONSerialization.jsonObject(with: response as Data, options: .allowFragments) as! [String:Any]
                if let fullname = json["fullname"] as? String{
                    self.removeActivityIndicator()
                    OperationQueue.main.addBarrierBlock {
                        self.name = fullname
                        self.performSegue(withIdentifier: "NameSegue", sender: self)
                    }
                }
            }catch{
                
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "NameSegue"{
            let destinationVC = segue.destination as! NameViewController
            destinationVC.fullname = name
        }
    }
    
    @IBAction func submitAction(sender: UIButton) {
        let resource:String = DomainTextField.text!
        if DomainTextField.text!.isEmpty{
            let alert = UIAlertController(title: "Error", message:"Please Provide Domain", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                self.DomainTextField.becomeFirstResponder()
                
            })
            self.present(alert, animated: true){}
            return
        }
        if !matches(searchString: resource){
            let alert = UIAlertController(title: "Error", message:"Invalid Domain", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                self.DomainTextField.becomeFirstResponder()
                
            })
            self.present(alert, animated: true){}
            return
        }
        let storage:DefaultsStorage = DefaultsStorage()
        storage.saveDomain(domain: resource)
        
        authContext = ADAuthenticationContext(authority: Constants.authority, error: &er)
        authContext!.acquireToken(withResource: resource, clientId: Constants.Client_Id, redirectUri: Constants.Redirect_URL as URL){(result:ADAuthenticationResult!) in
            if(result.accessToken != nil){
                self.addActivityIndicator()
                let handler:ServiceHandler = ServiceHandler()
                handler.tag = "WhoAmI"
                handler.delegate = self
                handler.getMethod(accessToken: result.accessToken, serviceURL: "\(resource)\(Constants.WebAPI_URLs.WhoAmIRequest_URL)")
            }
        }
    }
    
    func matches(searchString:String)->Bool{
        return true
        let pattern = "https://[a-z]*.crm[2-9].dynamics.com"
        do{
            let regex = try NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
            let matchCount = regex.numberOfMatches(in: searchString, options: [], range: NSMakeRange(0, searchString.count))
            
            return matchCount > 0
        }catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            return false
        }
    }
    
    func addActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(frame: view.bounds)
        activityIndicator.activityIndicatorViewStyle = .whiteLarge
        activityIndicator.backgroundColor = UIColor(white: 0, alpha: 0.25)
        activityIndicator.startAnimating()
        view.addSubview(activityIndicator)
    }
    
    func removeActivityIndicator() {
        activityIndicator.removeFromSuperview()
        activityIndicator = nil
    }
    
}

